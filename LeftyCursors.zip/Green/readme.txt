﻿=== Green Cursor Set ===

By: Chris Kid (http://www.rw-designer.com/user/4872) CHRISTY@WANVIGS.NET

Download: http://www.rw-designer.com/cursor-set/greengreen

Author's decription:

Green cursors with blue shadow.  Right and left handed cursors included.

==========

License: Creative Commons - Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Noncommercial - You may not use this work for commercial purposes.